package com.cn.upscaler.upscale;

/** Describes how big the output should be for one upscale job. */
public final class UpscaleRequest {

    public final UpscaleMode mode;
    public final int targetLongestEdge; // used when mode == TARGET_RESOLUTION
    public final int scaleFactor;       // used when mode == SCALE_FACTOR

    public static UpscaleRequest targetResolution(int longestEdge) {
        return new UpscaleRequest(UpscaleMode.TARGET_RESOLUTION, longestEdge, 0);
    }

    public static UpscaleRequest scaleFactor(int factor) {
        return new UpscaleRequest(UpscaleMode.SCALE_FACTOR, 0, factor);
    }

    private UpscaleRequest(UpscaleMode mode, int targetLongestEdge, int scaleFactor) {
        this.mode = mode;
        this.targetLongestEdge = targetLongestEdge;
        this.scaleFactor = scaleFactor;
    }
}
