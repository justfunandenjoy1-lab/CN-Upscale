package com.cn.upscaler.upscale;

import android.graphics.Bitmap;

/**
 * Real (algorithmic, non-generative) super-resolution pipeline: Lanczos-3
 * resampling followed by edge-adaptive, two-scale detail enhancement.
 *
 * This is NOT a neural network -- it doesn't invent detail the source never
 * had -- but it is a genuine, well-established class of super-resolution
 * algorithm (the same family used by professional resampling and photo
 * tools), and it provably changes pixel content rather than just enlarging
 * the file: it produces measurably sharper edges and more retained detail
 * than a plain bilinear/bicubic stretch (see the algorithm notes in the
 * project README for how this was checked before shipping).
 *
 * Processing happens in horizontal row bands so peak memory stays bounded
 * by (band height x image width) rather than the full output size, no
 * matter how large the requested output is. Each band reads only the
 * source rows it needs straight from the source Bitmap and writes straight
 * into the destination Bitmap, so no full-size pixel array is ever
 * allocated in addition to the two Bitmaps themselves.
 */
public final class BandedUpscaler {

    /** Target pixel count per band; actual band height is derived from this
     *  and the destination width so very wide images still use modest bands. */
    private static final int TARGET_BAND_PIXELS = 800_000;
    private static final int MIN_BAND_HEIGHT = 32;
    private static final int MAX_BAND_HEIGHT = 256;

    private static final float AMOUNT_FINE = 0.7f;
    private static final float AMOUNT_COARSE = 0.5f;

    public interface ProgressListener {
        /** Called with progress in [0,1] for the current image. */
        void onProgress(float progress);
    }

    private BandedUpscaler() {}

    public static void process(Bitmap source, int srcW, int srcH, Bitmap dest, int dstW, int dstH,
                                ProgressListener listener) {
        int bandHeight = Math.max(MIN_BAND_HEIGHT, Math.min(MAX_BAND_HEIGHT, TARGET_BAND_PIXELS / Math.max(1, dstW)));
        int margin = DetailEnhancer.COARSE_RADIUS;
        double scaleY = (double) srcH / (double) dstH;

        // Horizontal taps depend only on (srcW, dstW), never on the band
        // being processed, so they are built once and reused for every band.
        LanczosResampler.Taps horizontalTaps = LanczosResampler.buildTaps(srcW, dstW, 0, dstW);

        int y = 0;
        while (y < dstH) {
            int bandRows = Math.min(bandHeight, dstH - y);

            int paddedLo = Math.max(0, y - margin);
            int paddedHi = Math.min(dstH, y + bandRows + margin);
            int paddedRows = paddedHi - paddedLo;

            // Source rows needed to produce destination rows [paddedLo, paddedHi)
            // through the vertical Lanczos pass.
            double sLoF = (paddedLo + 0.5) * scaleY - 0.5 - LanczosResampler.A;
            double sHiF = (paddedHi - 1 + 0.5) * scaleY - 0.5 + LanczosResampler.A;
            int sLo = Math.max(0, Math.min(srcH - 1, (int) Math.floor(sLoF)));
            int sHi = Math.min(srcH, (int) Math.ceil(sHiF) + 1);
            if (sHi <= sLo) sHi = Math.min(srcH, sLo + 1);
            int sRows = sHi - sLo;

            int[] srcPixels = new int[sRows * srcW];
            source.getPixels(srcPixels, 0, srcW, 0, sLo, srcW, sRows);

            float[] srcR = new float[sRows * srcW];
            float[] srcG = new float[sRows * srcW];
            float[] srcB = new float[sRows * srcW];
            for (int i = 0; i < srcPixels.length; i++) {
                int p = srcPixels[i];
                srcR[i] = (p >> 16) & 0xFF;
                srcG[i] = (p >> 8) & 0xFF;
                srcB[i] = p & 0xFF;
            }

            float[] hR = LanczosResampler.resizeRowsHorizontal(srcR, sRows, srcW, horizontalTaps, dstW);
            float[] hG = LanczosResampler.resizeRowsHorizontal(srcG, sRows, srcW, horizontalTaps, dstW);
            float[] hB = LanczosResampler.resizeRowsHorizontal(srcB, sRows, srcW, horizontalTaps, dstW);

            float[] bandR = LanczosResampler.resizeColumnsVerticalBand(hR, sLo, sRows, dstW, srcH, dstH, paddedLo, paddedRows);
            float[] bandG = LanczosResampler.resizeColumnsVerticalBand(hG, sLo, sRows, dstW, srcH, dstH, paddedLo, paddedRows);
            float[] bandB = LanczosResampler.resizeColumnsVerticalBand(hB, sLo, sRows, dstW, srcH, dstH, paddedLo, paddedRows);

            // Shared luminance edge map drives sharpening strength for all
            // three channels, so color fringing isn't introduced at edges.
            float[] luma = new float[paddedRows * dstW];
            for (int i = 0; i < luma.length; i++) {
                luma[i] = 0.299f * bandR[i] + 0.587f * bandG[i] + 0.114f * bandB[i];
            }
            float[] edgeWeight = DetailEnhancer.computeEdgeWeight(DetailEnhancer.sobelMagnitude(luma, paddedRows, dstW));

            float[] sharpR = DetailEnhancer.sharpenChannel(bandR, paddedRows, dstW, edgeWeight, AMOUNT_FINE, AMOUNT_COARSE);
            float[] sharpG = DetailEnhancer.sharpenChannel(bandG, paddedRows, dstW, edgeWeight, AMOUNT_FINE, AMOUNT_COARSE);
            float[] sharpB = DetailEnhancer.sharpenChannel(bandB, paddedRows, dstW, edgeWeight, AMOUNT_FINE, AMOUNT_COARSE);

            // Crop the padded band back to the true [y, y+bandRows) core and pack to ARGB.
            int cropLo = y - paddedLo;
            int[] outPixels = new int[bandRows * dstW];
            for (int r = 0; r < bandRows; r++) {
                int rowBase = (cropLo + r) * dstW;
                int outBase = r * dstW;
                for (int x = 0; x < dstW; x++) {
                    int idx = rowBase + x;
                    int rr = Math.round(sharpR[idx]);
                    int gg = Math.round(sharpG[idx]);
                    int bb = Math.round(sharpB[idx]);
                    outPixels[outBase + x] = 0xFF000000 | (rr << 16) | (gg << 8) | bb;
                }
            }
            dest.setPixels(outPixels, 0, dstW, 0, y, dstW, bandRows);

            y += bandRows;
            if (listener != null) {
                listener.onProgress(Math.min(1f, (float) y / (float) dstH));
            }
        }
    }
}
