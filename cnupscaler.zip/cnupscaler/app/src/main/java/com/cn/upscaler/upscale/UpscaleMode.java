package com.cn.upscaler.upscale;

/** The two ways the user can specify how big the output should be. */
public enum UpscaleMode {
    /** Upscale to a target longest-edge resolution (e.g. 2K/4K/8K). */
    TARGET_RESOLUTION,
    /** Upscale by an exact multiplier of the source size (e.g. 2x/4x/8x). */
    SCALE_FACTOR
}
