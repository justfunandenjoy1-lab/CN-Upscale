package com.cn.upscaler.upscale;

/** Outcome of one image's upscale job. */
public final class UpscaleResult {

    public enum Kind { SUCCESS, SKIPPED, FAILED }

    public final Kind kind;
    public final String message; // set for skipped/failed results
    public final int srcWidth, srcHeight;
    public final int dstWidth, dstHeight;
    public final boolean capped; // true if the requested size was reduced for memory safety
    public final String savedFileName;

    public static UpscaleResult skipped(String message, int srcW, int srcH) {
        return new UpscaleResult(Kind.SKIPPED, message, srcW, srcH, 0, 0, false, null);
    }

    public static UpscaleResult failed(String message) {
        return new UpscaleResult(Kind.FAILED, message, 0, 0, 0, 0, false, null);
    }

    public static UpscaleResult ok(int srcW, int srcH, int dstW, int dstH, boolean capped, String savedFileName) {
        return new UpscaleResult(Kind.SUCCESS, null, srcW, srcH, dstW, dstH, capped, savedFileName);
    }

    private UpscaleResult(Kind kind, String message, int srcW, int srcH, int dstW, int dstH,
                           boolean capped, String savedFileName) {
        this.kind = kind;
        this.message = message;
        this.srcWidth = srcW;
        this.srcHeight = srcH;
        this.dstWidth = dstW;
        this.dstHeight = dstH;
        this.capped = capped;
        this.savedFileName = savedFileName;
    }
}
