package com.cn.upscaler.upscale;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Runs one image through the real (Lanczos + edge-adaptive detail
 * enhancement) upscaling pipeline and saves the result. Fully offline: only
 * reads the picked image and writes to local MediaStore, no network access.
 */
public final class UpscaleEngine {

    /** Longest-edge safety cap so the final Bitmap allocation and JPEG
     *  encoding stay within limits that hold up on typical Android devices. */
    public static final int MAX_OUTPUT_LONG_EDGE = 8000;
    /** Total-pixel safety cap (~192MB for the ARGB_8888 output bitmap at the extreme). */
    public static final long MAX_OUTPUT_PIXELS = 48_000_000L;

    private UpscaleEngine() {}

    public static UpscaleResult run(Context context, Uri sourceUri, UpscaleRequest request,
                                     BandedUpscaler.ProgressListener listener) {
        Bitmap source = null;
        Bitmap dest = null;
        try {
            source = decodeBitmap(context, sourceUri);
            if (source == null) {
                return UpscaleResult.failed("Unable to decode image");
            }
            int srcW = source.getWidth();
            int srcH = source.getHeight();

            Sizing sizing = computeTargetDims(srcW, srcH, request);
            if (sizing.skipReason != null) {
                return UpscaleResult.skipped(sizing.skipReason, srcW, srcH);
            }

            dest = Bitmap.createBitmap(sizing.width, sizing.height, Bitmap.Config.ARGB_8888);
            BandedUpscaler.process(source, srcW, srcH, dest, sizing.width, sizing.height, listener);

            String savedName = saveBitmap(context, dest, sizing.width, sizing.height);
            return UpscaleResult.ok(srcW, srcH, sizing.width, sizing.height, sizing.capped, savedName);
        } catch (Throwable t) {
            return UpscaleResult.failed(t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName());
        } finally {
            if (source != null && !source.isRecycled()) source.recycle();
            if (dest != null && !dest.isRecycled()) dest.recycle();
        }
    }

    private static final class Sizing {
        int width, height;
        boolean capped;
        String skipReason; // non-null means: don't process, show this instead
    }

    private static Sizing computeTargetDims(int srcW, int srcH, UpscaleRequest request) {
        Sizing s = new Sizing();
        int dstW, dstH;

        if (request.mode == UpscaleMode.TARGET_RESOLUTION) {
            int targetLongest = request.targetLongestEdge;
            int srcLongest = Math.max(srcW, srcH);
            if (srcLongest >= targetLongest) {
                s.skipReason = "Already at or above the requested size (" + srcW + "\u00d7" + srcH + ")";
                return s;
            }
            float scale = (float) targetLongest / srcLongest;
            dstW = Math.round(srcW * scale);
            dstH = Math.round(srcH * scale);
        } else {
            dstW = srcW * request.scaleFactor;
            dstH = srcH * request.scaleFactor;
        }

        boolean capped = false;
        int longest = Math.max(dstW, dstH);
        if (longest > MAX_OUTPUT_LONG_EDGE) {
            float scale = (float) MAX_OUTPUT_LONG_EDGE / longest;
            dstW = Math.max(1, Math.round(dstW * scale));
            dstH = Math.max(1, Math.round(dstH * scale));
            capped = true;
        }
        long pixels = (long) dstW * (long) dstH;
        if (pixels > MAX_OUTPUT_PIXELS) {
            float scale = (float) Math.sqrt((double) MAX_OUTPUT_PIXELS / (double) pixels);
            dstW = Math.max(1, Math.round(dstW * scale));
            dstH = Math.max(1, Math.round(dstH * scale));
            capped = true;
        }

        if (dstW <= srcW && dstH <= srcH) {
            s.skipReason = "Source is already near the safe processing limit for this device ("
                    + srcW + "\u00d7" + srcH + "); a larger output isn't possible within safe memory limits";
            return s;
        }

        s.width = dstW;
        s.height = dstH;
        s.capped = capped;
        return s;
    }

    private static Bitmap decodeBitmap(Context context, Uri uri) throws Exception {
        ContentResolver cr = context.getContentResolver();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = cr.openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inPreferredConfig = Bitmap.Config.ARGB_8888;
        int maxSource = 4096, sample = 1;
        while (bounds.outWidth / sample > maxSource * 2 || bounds.outHeight / sample > maxSource * 2) sample *= 2;
        opt.inSampleSize = sample;
        try (InputStream in = cr.openInputStream(uri)) {
            return BitmapFactory.decodeStream(in, null, opt);
        }
    }

    private static String saveBitmap(Context context, Bitmap bitmap, int w, int h) throws Exception {
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(new Date());
        String name = "CN_Upscaled_" + w + "x" + h + "_" + stamp + ".jpg";
        ContentResolver cr = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CN Upscaler");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES), "CN Upscaler");
            if (!dir.exists()) //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
            values.put(MediaStore.Images.Media.DATA, new File(dir, name).getAbsolutePath());
        }
        Uri outUri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (outUri == null) throw new Exception("MediaStore insert failed");
        boolean ok;
        try (OutputStream out = cr.openOutputStream(outUri)) {
            if (out == null) throw new Exception("Output stream unavailable");
            ok = bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out);
        }
        if (!ok) {
            cr.delete(outUri, null, null);
            throw new Exception("JPEG encoding failed");
        }
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Images.Media.IS_PENDING, 0);
            cr.update(outUri, done, null, null);
        }
        return name;
    }
}
