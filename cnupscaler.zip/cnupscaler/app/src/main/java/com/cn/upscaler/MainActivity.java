package com.cn.upscaler;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_IMAGES = 1001;
    private final ArrayList<Uri> selected = new ArrayList<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextView selectedText, statusText;
    private Spinner targetSpinner;
    private ProgressBar progress;
    private Button processButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 36, 32, 24);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("CN Upscaler"); title.setTextSize(28); title.setTextColor(Color.rgb(40,40,40));
        title.setGravity(Gravity.CENTER_HORIZONTAL); title.setPadding(0,0,0,14);
        root.addView(title, lp());

        TextView note = new TextView(this);
        note.setText("Offline image upscaler • 2K / 4K / 8K • Batch processing"); note.setTextSize(15);
        note.setTextColor(Color.DKGRAY); note.setGravity(Gravity.CENTER_HORIZONTAL); note.setPadding(0,0,0,24);
        root.addView(note, lp());

        Button pick = new Button(this); pick.setText("Select Images");
        pick.setOnClickListener(v -> pickImages()); root.addView(pick, lp());

        selectedText = new TextView(this); selectedText.setText("No images selected"); selectedText.setTextSize(14); selectedText.setPadding(0,18,0,18);
        root.addView(selectedText, lp());

        TextView targetLabel = new TextView(this); targetLabel.setText("Target resolution"); targetLabel.setTextSize(16); targetLabel.setTextColor(Color.DKGRAY);
        root.addView(targetLabel, lp());

        targetSpinner = new Spinner(this);
        String[] targets = {"2K — 2560 px longest side", "4K — 3840 px longest side", "8K — 7680 px longest side"};
        targetSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, targets));
        root.addView(targetSpinner, lp());

        processButton = new Button(this); processButton.setText("Upscale & Save"); processButton.setEnabled(false);
        processButton.setOnClickListener(v -> startProcessing()); root.addView(processButton, lp());

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); progress.setMax(100); progress.setProgress(0);
        progress.setVisibility(View.GONE); root.addView(progress, lp());

        statusText = new TextView(this); statusText.setText("Files are processed locally on this device."); statusText.setTextSize(14); statusText.setPadding(0,18,0,0);
        root.addView(statusText, lp());
        setContentView(root);
    }

    private LinearLayout.LayoutParams lp() { return new LinearLayout.LayoutParams(-1, -2); }

    private void pickImages() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*"); intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_IMAGES);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGES || resultCode != RESULT_OK || data == null) return;
        selected.clear();
        if (data.getClipData() != null) {
            for (int i=0;i<data.getClipData().getItemCount();i++) selected.add(data.getClipData().getItemAt(i).getUri());
        } else if (data.getData() != null) selected.add(data.getData());
        selectedText.setText(selected.size() + " image(s) selected"); processButton.setEnabled(!selected.isEmpty());
    }

    private void startProcessing() {
        if (selected.isEmpty()) return;
        final int target = targetSpinner.getSelectedItemPosition() == 0 ? 2560 : targetSpinner.getSelectedItemPosition() == 1 ? 3840 : 7680;
        processButton.setEnabled(false); progress.setVisibility(View.VISIBLE); progress.setProgress(0);
        statusText.setText("Processing 0 / " + selected.size());
        ArrayList<Uri> jobs = new ArrayList<>(selected);
        executor.execute(() -> {
            int done = 0, failed = 0;
            for (Uri uri : jobs) {
                try { processOne(uri, target); } catch (Throwable t) { failed++; }
                done++;
                final int d=done, f=failed;
                runOnUiThread(() -> { progress.setProgress((int)(d*100f/jobs.size())); statusText.setText("Processing " + d + " / " + jobs.size() + (f>0?" • Failed: "+f:"")); });
            }
            final int f=failed;
            runOnUiThread(() -> { processButton.setEnabled(!selected.isEmpty()); statusText.setText("Finished • Saved: " + (jobs.size()-f) + " • Failed: " + f); Toast.makeText(this,"Upscaling finished",Toast.LENGTH_SHORT).show(); });
        });
    }

    private void processOne(Uri uri, int targetLongest) throws Exception {
        Bitmap source = decodeBitmap(uri);
        if (source == null) throw new Exception("Unable to decode image");
        int sw=source.getWidth(), sh=source.getHeight();
        if (Math.max(sw, sh) >= targetLongest) { source.recycle(); return; }
        float scale = (float) targetLongest / Math.max(sw, sh);
        int tw=Math.max(1, Math.round(sw*scale)), th=Math.max(1, Math.round(sh*scale));
        Bitmap out = Bitmap.createScaledBitmap(source, tw, th, true);
        source.recycle();
        saveBitmap(uri, out, tw, th, targetLongest);
        out.recycle();
    }

    private Bitmap decodeBitmap(Uri uri) throws Exception {
        ContentResolver cr=getContentResolver();
        BitmapFactory.Options bounds=new BitmapFactory.Options(); bounds.inJustDecodeBounds=true;
        try(InputStream in=cr.openInputStream(uri)){ BitmapFactory.decodeStream(in,null,bounds); }
        if(bounds.outWidth<=0 || bounds.outHeight<=0) return null;
        BitmapFactory.Options opt=new BitmapFactory.Options(); opt.inPreferredConfig=Bitmap.Config.ARGB_8888;
        // Keep source reasonably sized before the final upscale to reduce OOM risk.
        int maxSource=4096, sample=1;
        while(bounds.outWidth/sample>maxSource*2 || bounds.outHeight/sample>maxSource*2) sample*=2;
        opt.inSampleSize=sample;
        try(InputStream in=cr.openInputStream(uri)){ return BitmapFactory.decodeStream(in,null,opt); }
    }

    private void saveBitmap(Uri sourceUri, Bitmap bitmap, int w, int h, int target) throws Exception {
        String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date());
        String name="CN_Upscaled_"+target+"_"+stamp+".jpg";
        ContentValues values=new ContentValues(); values.put(MediaStore.Images.Media.DISPLAY_NAME,name); values.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
        if(Build.VERSION.SDK_INT>=29){ values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/CN Upscaler"); values.put(MediaStore.Images.Media.IS_PENDING,1); }
        Uri outUri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        if(outUri==null) throw new Exception("MediaStore insert failed");
        boolean ok=false;
        try(OutputStream out=getContentResolver().openOutputStream(outUri)){ if(out==null) throw new Exception("Output stream unavailable"); ok=bitmap.compress(Bitmap.CompressFormat.JPEG,95,out); }
        if(!ok){ getContentResolver().delete(outUri,null,null); throw new Exception("JPEG encoding failed"); }
        if(Build.VERSION.SDK_INT>=29){ ContentValues done=new ContentValues(); done.put(MediaStore.Images.Media.IS_PENDING,0); getContentResolver().update(outUri,done,null,null); }
    }

    @Override protected void onDestroy(){ super.onDestroy(); executor.shutdownNow(); }
}
