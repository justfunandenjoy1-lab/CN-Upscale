package com.cn.upscaler;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.cn.upscaler.databinding.ActivityMainBinding;
import com.cn.upscaler.upscale.UpscaleEngine;
import com.cn.upscaler.upscale.UpscaleMode;
import com.cn.upscaler.upscale.UpscaleRequest;
import com.cn.upscaler.upscale.UpscaleResult;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_IMAGES = 1001;
    private static final int STORAGE_PERMISSION_REQUEST = 1002;

    // Longest-edge targets for the resolution chips.
    private static final int RES_2K = 2560;
    private static final int RES_4K = 3840;
    private static final int RES_8K = 7680;

    private final ArrayList<Uri> selected = new ArrayList<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private ActivityMainBinding binding;
    private UpscaleMode currentMode = UpscaleMode.TARGET_RESOLUTION;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        wireUi();
    }

    private void wireUi() {
        binding.toggleGroupMode.check(R.id.btnModeResolution);
        binding.toggleGroupMode.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            if (checkedId == R.id.btnModeResolution) {
                currentMode = UpscaleMode.TARGET_RESOLUTION;
                binding.chipGroupResolution.setVisibility(View.VISIBLE);
                binding.chipGroupFactor.setVisibility(View.GONE);
            } else if (checkedId == R.id.btnModeFactor) {
                currentMode = UpscaleMode.SCALE_FACTOR;
                binding.chipGroupResolution.setVisibility(View.GONE);
                binding.chipGroupFactor.setVisibility(View.VISIBLE);
            }
        });

        binding.btnSelectImages.setOnClickListener(v -> pickImages());
        binding.btnProcess.setOnClickListener(v -> startProcessing());
    }

    private void pickImages() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_IMAGES);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_IMAGES || resultCode != RESULT_OK || data == null) return;

        selected.clear();
        if (data.getClipData() != null) {
            int count = data.getClipData().getItemCount();
            for (int i = 0; i < count; i++) selected.add(data.getClipData().getItemAt(i).getUri());
        } else if (data.getData() != null) {
            selected.add(data.getData());
        }

        binding.tvSelectedCount.setText(getString(R.string.images_selected, selected.size()));
        binding.btnProcess.setEnabled(!selected.isEmpty());
        binding.cardResult.setVisibility(View.GONE);

        if (!selected.isEmpty()) {
            loadThumbnail(selected.get(0));
        } else {
            binding.ivThumbnail.setVisibility(View.GONE);
        }
    }

    private void loadThumbnail(Uri uri) {
        executor.execute(() -> {
            Bitmap thumb = decodeThumbnail(uri, 240);
            if (thumb != null) {
                runOnUiThread(() -> {
                    binding.ivThumbnail.setImageBitmap(thumb);
                    binding.ivThumbnail.setVisibility(View.VISIBLE);
                });
            }
        });
    }

    private Bitmap decodeThumbnail(Uri uri, int maxDim) {
        try {
            ContentResolver cr = getContentResolver();
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = cr.openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
            int sample = 1;
            while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2;
            BitmapFactory.Options opt = new BitmapFactory.Options();
            opt.inSampleSize = sample;
            try (InputStream in = cr.openInputStream(uri)) {
                return BitmapFactory.decodeStream(in, null, opt);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private UpscaleRequest buildRequest() {
        if (currentMode == UpscaleMode.TARGET_RESOLUTION) {
            int checkedId = binding.chipGroupResolution.getCheckedChipId();
            int longestEdge = RES_2K;
            if (checkedId == R.id.chip4k) longestEdge = RES_4K;
            else if (checkedId == R.id.chip8k) longestEdge = RES_8K;
            return UpscaleRequest.targetResolution(longestEdge);
        } else {
            int checkedId = binding.chipGroupFactor.getCheckedChipId();
            int factor = 2;
            if (checkedId == R.id.chip4x) factor = 4;
            else if (checkedId == R.id.chip8x) factor = 8;
            return UpscaleRequest.scaleFactor(factor);
        }
    }

    private void startProcessing() {
        if (selected.isEmpty()) return;

        if (Build.VERSION.SDK_INT <= 28 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_REQUEST);
            return;
        }

        UpscaleRequest request = buildRequest();

        binding.btnProcess.setEnabled(false);
        binding.btnSelectImages.setEnabled(false);
        binding.progressIndicator.setVisibility(View.VISIBLE);
        binding.progressIndicator.setProgress(0);
        binding.cardResult.setVisibility(View.GONE);
        binding.tvStatus.setText(getString(R.string.status_processing, 0, selected.size()));

        ArrayList<Uri> jobs = new ArrayList<>(selected);
        executor.execute(() -> runJobs(jobs, request));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != STORAGE_PERMISSION_REQUEST) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (granted) {
            startProcessing();
        } else {
            Toast.makeText(this, "Storage permission is needed to save upscaled images on this Android version.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void runJobs(ArrayList<Uri> jobs, UpscaleRequest request) {
        int saved = 0, skipped = 0, failed = 0;
        UpscaleResult lastOk = null;

        for (int i = 0; i < jobs.size(); i++) {
            final int index = i;
            Uri uri = jobs.get(i);

            UpscaleResult result = UpscaleEngine.run(this, uri, request, progress -> {
                float overall = (index + progress) / jobs.size();
                int percent = Math.round(overall * 100);
                runOnUiThread(() -> binding.progressIndicator.setProgress(percent));
            });

            switch (result.kind) {
                case SUCCESS:
                    saved++;
                    lastOk = result;
                    break;
                case SKIPPED:
                    skipped++;
                    break;
                default:
                    failed++;
                    break;
            }

            final int doneCount = i + 1;
            runOnUiThread(() -> binding.tvStatus.setText(getString(R.string.status_processing, doneCount, jobs.size())));
        }

        final int s = saved, sk = skipped, f = failed;
        final UpscaleResult finalResult = lastOk;
        runOnUiThread(() -> finishProcessing(s, sk, f, finalResult));
    }

    private void finishProcessing(int saved, int skipped, int failed, UpscaleResult lastOk) {
        binding.progressIndicator.setProgress(100);
        binding.btnProcess.setEnabled(!selected.isEmpty());
        binding.btnSelectImages.setEnabled(true);
        binding.tvStatus.setText(getString(R.string.status_done, saved, skipped, failed));
        Toast.makeText(this, getString(R.string.status_done, saved, skipped, failed), Toast.LENGTH_SHORT).show();

        if (lastOk != null) {
            binding.cardResult.setVisibility(View.VISIBLE);
            binding.tvResultDetail.setText(getString(R.string.result_detail_format,
                    lastOk.srcWidth, lastOk.srcHeight, lastOk.dstWidth, lastOk.dstHeight));
            binding.tvResultCappedNote.setVisibility(lastOk.capped ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
