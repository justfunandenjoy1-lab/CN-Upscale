package com.cn.upscaler.upscale;

/**
 * Separable Lanczos-3 resampling on single-channel float pixel data
 * (values in the 0..255 range; not clamped here).
 *
 * This is the geometric core of the real upscaling pipeline: it computes
 * a proper windowed-sinc reconstruction of the image at the new pixel
 * grid, which is what produces genuinely sharper, more detailed output
 * than Android's built-in bilinear {@code Bitmap.createScaledBitmap}.
 *
 * All methods are stateless and operate on caller-supplied row ranges,
 * so callers (see {@link BandedUpscaler}) control memory use by choosing
 * how many rows to resample at a time instead of always processing a
 * full-size image.
 */
final class LanczosResampler {

    /** Lanczos window radius (Lanczos-3: a=3, 6 taps per axis). */
    static final int A = 3;
    private static final int TAPS = 2 * A;

    private LanczosResampler() {}

    private static double sinc(double x) {
        if (x == 0.0) return 1.0;
        double px = Math.PI * x;
        return Math.sin(px) / px;
    }

    private static double weight(double x) {
        if (x <= -A || x >= A) return 0.0;
        return sinc(x) * sinc(x / A);
    }

    /** Precomputed, normalized resampling taps for one axis. */
    static final class Taps {
        final int[][] indices;   // [dstCount][TAPS] clamped source indices
        final float[][] weights; // [dstCount][TAPS] normalized weights (sum to 1)

        Taps(int dstCount) {
            indices = new int[dstCount][TAPS];
            weights = new float[dstCount][TAPS];
        }
    }

    /**
     * Builds resampling taps mapping destination indices
     * [dstStart, dstStart+dstCount) of a virtual full-length destination axis
     * (length fullDstLen) back onto a source axis of length fullSrcLen,
     * clamped to [0, fullSrcLen-1].
     */
    static Taps buildTaps(int fullSrcLen, int fullDstLen, int dstStart, int dstCount) {
        Taps t = new Taps(dstCount);
        double scale = (double) fullSrcLen / (double) fullDstLen;
        for (int di = 0; di < dstCount; di++) {
            int d = dstStart + di;
            double s = (d + 0.5) * scale - 0.5;
            int i0 = (int) Math.floor(s) - A + 1;
            double wsum = 0;
            for (int k = 0; k < TAPS; k++) {
                int srcIndex = i0 + k;
                double w = weight(s - srcIndex);
                int clamped = Math.max(0, Math.min(fullSrcLen - 1, srcIndex));
                t.indices[di][k] = clamped;
                t.weights[di][k] = (float) w;
                wsum += w;
            }
            if (wsum == 0.0) wsum = 1.0;
            for (int k = 0; k < TAPS; k++) {
                t.weights[di][k] = (float) (t.weights[di][k] / wsum);
            }
        }
        return t;
    }

    /**
     * Resamples every row of {@code src} ({@code srcRows} x {@code srcW})
     * horizontally using precomputed {@code taps} (built for the full
     * destination width). Horizontal resizing is never band-limited: the
     * full source row width is always available, so this always covers the
     * complete destination width.
     */
    static float[] resizeRowsHorizontal(float[] src, int srcRows, int srcW, Taps taps, int dstW) {
        float[] out = new float[srcRows * dstW];
        for (int r = 0; r < srcRows; r++) {
            int rowBase = r * srcW;
            int outBase = r * dstW;
            for (int x = 0; x < dstW; x++) {
                int[] idx = taps.indices[x];
                float[] w = taps.weights[x];
                float sum = 0f;
                for (int k = 0; k < TAPS; k++) {
                    sum += w[k] * src[rowBase + idx[k]];
                }
                out[outBase + x] = sum;
            }
        }
        return out;
    }

    /**
     * Resamples a vertical band. {@code src} holds {@code srcRows} full-width
     * rows of the source axis starting at true source row
     * {@code srcRowOffset} (i.e. {@code src[0]} is true source row
     * {@code srcRowOffset}). Produces {@code dstRowCount} destination rows
     * starting at true destination row {@code dstRowStart}, mapped against
     * the full axis lengths {@code fullSrcH}/{@code fullDstH}.
     */
    static float[] resizeColumnsVerticalBand(float[] src, int srcRowOffset, int srcRows, int width,
                                              int fullSrcH, int fullDstH, int dstRowStart, int dstRowCount) {
        Taps taps = buildTaps(fullSrcH, fullDstH, dstRowStart, dstRowCount);
        float[] out = new float[dstRowCount * width];
        int maxLocal = srcRows - 1;
        int[] localBase = new int[TAPS];

        for (int di = 0; di < dstRowCount; di++) {
            int[] idx = taps.indices[di];
            float[] w = taps.weights[di];
            for (int k = 0; k < TAPS; k++) {
                int local = idx[k] - srcRowOffset;
                if (local < 0) local = 0;
                else if (local > maxLocal) local = maxLocal;
                localBase[k] = local * width;
            }
            int outBase = di * width;
            for (int x = 0; x < width; x++) {
                float sum = 0f;
                for (int k = 0; k < TAPS; k++) {
                    sum += w[k] * src[localBase[k] + x];
                }
                out[outBase + x] = sum;
            }
        }
        return out;
    }
}
