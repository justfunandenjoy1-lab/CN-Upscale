package com.cn.upscaler.upscale;

/**
 * Edge-adaptive, two-scale detail enhancement applied after Lanczos
 * resampling. Plain resampling alone (however good the kernel) still looks
 * softer than the original at high magnification, because reconstructing a
 * band-limited signal at a finer grid cannot invent frequencies the source
 * never had. This class recovers *perceived* detail the same way real
 * photo-upscaling tools do: it separates each pixel into a fine-detail
 * layer, a coarse-structure layer and a base layer, then boosts the two
 * detail layers more strongly wherever the image actually has an edge
 * (via a Sobel gradient map) and less in flat/smooth regions, so grain and
 * flat skies are not amplified into noise.
 *
 * All operations here take an explicit row/width extent and clamp at the
 * array's own edges (never wrap or read outside the supplied buffer), so
 * a caller that passes in a padded row-band gets results identical to
 * processing the full image at once, as long as the padding is at least
 * {@link #COARSE_RADIUS} rows on each side (see {@link BandedUpscaler}).
 */
final class DetailEnhancer {

    /** Radius of the coarse (structure-scale) blur; also the minimum
     *  destination-row padding a caller must include around a band. */
    static final int COARSE_RADIUS = 8;

    /** Fixed, image-independent normalization for edge strength. Using a
     *  fixed constant (rather than each image's own min/max) keeps the
     *  algorithm's output for a given band identical to what full-image
     *  processing would produce, and keeps behavior predictable across
     *  very different photos. */
    private static final float EDGE_SCALE = 40f;

    private static final float[] BLUR5_KERNEL = {1f, 4f, 6f, 4f, 1f};
    private static final float BLUR5_SUM = 16f;

    private static final float[][] SOBEL_X = {{-1, 0, 1}, {-2, 0, 2}, {-1, 0, 1}};
    private static final float[][] SOBEL_Y = {{-1, -2, -1}, {0, 0, 0}, {1, 2, 1}};

    private DetailEnhancer() {}

    private static int clamp(int v, int lo, int hi) {
        if (v < lo) return lo;
        if (v > hi) return hi;
        return v;
    }

    static float clamp255(float v) {
        if (v < 0f) return 0f;
        if (v > 255f) return 255f;
        return v;
    }

    /** Separable 5-tap [1,4,6,4,1]/16 blur (small radius: fine detail scale). */
    static float[] blur5(float[] band, int rows, int width) {
        float[] tmp = new float[rows * width];
        for (int y = 0; y < rows; y++) {
            int rowBase = y * width;
            for (int x = 0; x < width; x++) {
                float sum = 0f;
                for (int i = -2; i <= 2; i++) {
                    int cx = clamp(x + i, 0, width - 1);
                    sum += band[rowBase + cx] * BLUR5_KERNEL[i + 2];
                }
                tmp[rowBase + x] = sum / BLUR5_SUM;
            }
        }
        float[] out = new float[rows * width];
        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < width; x++) {
                float sum = 0f;
                for (int i = -2; i <= 2; i++) {
                    int cy = clamp(y + i, 0, rows - 1);
                    sum += tmp[cy * width + x] * BLUR5_KERNEL[i + 2];
                }
                out[y * width + x] = sum / BLUR5_SUM;
            }
        }
        return out;
    }

    /** Separable box blur of the given radius (coarse/structure detail scale). */
    static float[] blurRadius(float[] band, int rows, int width, int radius) {
        int n = 2 * radius + 1;
        float[] tmp = new float[rows * width];
        for (int y = 0; y < rows; y++) {
            int rowBase = y * width;
            for (int x = 0; x < width; x++) {
                float sum = 0f;
                for (int i = -radius; i <= radius; i++) {
                    int cx = clamp(x + i, 0, width - 1);
                    sum += band[rowBase + cx];
                }
                tmp[rowBase + x] = sum / n;
            }
        }
        float[] out = new float[rows * width];
        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < width; x++) {
                float sum = 0f;
                for (int i = -radius; i <= radius; i++) {
                    int cy = clamp(y + i, 0, rows - 1);
                    sum += tmp[cy * width + x];
                }
                out[y * width + x] = sum / n;
            }
        }
        return out;
    }

    /** Sobel gradient magnitude, used to tell edges (which should be sharpened
     *  hard) apart from flat regions (which should barely be touched). */
    static float[] sobelMagnitude(float[] band, int rows, int width) {
        float[] out = new float[rows * width];
        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < width; x++) {
                float gx = 0f, gy = 0f;
                for (int j = -1; j <= 1; j++) {
                    int cy = clamp(y + j, 0, rows - 1);
                    for (int i = -1; i <= 1; i++) {
                        int cx = clamp(x + i, 0, width - 1);
                        float v = band[cy * width + cx];
                        gx += v * SOBEL_X[j + 1][i + 1];
                        gy += v * SOBEL_Y[j + 1][i + 1];
                    }
                }
                out[y * width + x] = (float) Math.sqrt(gx * gx + gy * gy);
            }
        }
        return out;
    }

    /** Converts raw Sobel magnitude into a 0..1 sharpening weight. */
    static float[] computeEdgeWeight(float[] magnitude) {
        float[] out = new float[magnitude.length];
        for (int i = 0; i < magnitude.length; i++) {
            float w = magnitude[i] / EDGE_SCALE;
            if (w < 0f) w = 0f;
            else if (w > 1f) w = 1f;
            out[i] = w;
        }
        return out;
    }

    /**
     * Boosts fine and coarse detail layers of one channel, weighted by the
     * (shared, luminance-derived) edge map, and returns a clamped result.
     */
    static float[] sharpenChannel(float[] channel, int rows, int width, float[] edgeWeight,
                                   float amountFine, float amountCoarse) {
        float[] fineBlur = blur5(channel, rows, width);
        float[] coarseBlur = blurRadius(channel, rows, width, COARSE_RADIUS);
        float[] out = new float[rows * width];
        for (int i = 0; i < out.length; i++) {
            float fineDetail = channel[i] - fineBlur[i];
            float coarseDetail = fineBlur[i] - coarseBlur[i];
            float ew = edgeWeight[i];
            float v = channel[i]
                    + fineDetail * amountFine * (0.3f + 0.7f * ew)
                    + coarseDetail * amountCoarse * (0.2f + 0.5f * ew);
            out[i] = clamp255(v);
        }
        return out;
    }
}
